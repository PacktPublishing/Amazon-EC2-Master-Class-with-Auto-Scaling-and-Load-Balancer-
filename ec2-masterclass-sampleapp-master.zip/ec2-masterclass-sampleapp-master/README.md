
# Learning

This is a companion repository for my [**Amazon EC2 course on Udemy**](https://www.udemy.com/aws-ec2-masterclass/?couponCode=GITHUB)

Happy learning!

<p align="center">
    <a href="https://www.udemy.com/aws-ec2-masterclass/?couponCode=GITHUB">
        <img src="https://udemy-images.udemy.com/course/480x270/1527740_a494.jpg" alt="AWS EC2 Course Logo"/>
    </a>
</p>

# Content

 - Companion Java Application we'll use for this course
